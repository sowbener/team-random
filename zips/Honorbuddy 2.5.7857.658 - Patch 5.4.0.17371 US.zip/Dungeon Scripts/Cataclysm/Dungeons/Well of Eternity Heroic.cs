﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonBuddyScripts.Dungeon_Scripts.Burning_Crusade.Dungeons
{
    class Well_of_Eternity_Heroic
    {
    }
}
