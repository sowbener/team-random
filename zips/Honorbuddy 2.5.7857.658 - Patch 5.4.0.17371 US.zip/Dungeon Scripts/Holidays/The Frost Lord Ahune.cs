﻿//#define USE_DUNGEONBUDDY_DLL

using System;
using System.Collections.Generic;
using System.Linq;
using CommonBehaviors.Actions;
using Styx;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Frames;
using Styx.Helpers;
using Styx.Patchables;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Action = Styx.TreeSharp.Action;

#if USE_DUNGEONBUDDY_DLL
using Bots.DungeonBuddyDll;
using Bots.DungeonBuddyDll.Profiles;
using Bots.DungeonBuddyDll.Attributes;
using Bots.DungeonBuddyDll.Helpers;

namespace Bots.DungeonBuddyDll.Dungeon_Scripts.Mists_of_Pandaria
#else
    using Bots.DungeonBuddy.Profiles;
    using Bots.DungeonBuddy.Attributes;
    using Bots.DungeonBuddy.Helpers;
namespace Bots.DungeonBuddy.Dungeon_Scripts.Mists_of_Pandaria
#endif
{
    class The_Frost_Lord_Ahune : Dungeon
    {

        #region Overrides of Dungeon

        public override uint DungeonId
        {
            // get { return 286; }
            // to many issues to try script this dungeon... 
            get { return 2323232323; }
        }

        private readonly WoWPoint _entrance = new WoWPoint(740.8317, 7013.667, -72.97391);
        public override WoWPoint Entrance
        {
            get { return _entrance; }
        }


        public override void RemoveTargetsFilter(List<WoWObject> units)
        {
            units.RemoveAll(
                ret =>
                {
                    var unit = ret.ToUnit();
                    if (unit != null) { }
                    return false;
                });
        }

        public override void IncludeTargetsFilter(List<WoWObject> incomingunits, HashSet<WoWObject> outgoingunits)
        {
            foreach (var obj in incomingunits)
            {
                var unit = obj as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == FrozenCoreId && unit.Attackable)
                        outgoingunits.Add(unit);
                }
            }
        }

        public override void WeighTargetsFilter(List<Targeting.TargetPriority> units)
        {
            foreach (var priority in units)
            {
                var unit = priority.Object as WoWUnit;
                if (unit != null)
                {
                    if (unit.Entry == AhuneId)
                    {
                        priority.Score -= 10000;
                    }
                    else if (unit.Entry == FrozenCoreId)
                    {
                        priority.Score += 10000;
                    }
                }
            }
        }

        #endregion


        private static LocalPlayer Me
        {
            get { return StyxWoW.Me; }
        }

        const uint SlipperyFloorBunnyId = 25952;
        const uint SpankTargetBunnyId = 26190;
        private const uint IceStoneId = 187882;
        const uint FrozenCoreId = 25865;
        const uint AhuneId = 25740;
        [EncounterHandler(0)]
        public Composite RootBehavior()
        {
            const uint bigIceBlockId = 188142;
            const uint iceBlockId = 188067;
            const uint iseStoneMountId = 188072;
            const uint extraBigIceBlockId = 195000;

            AddAvoidObject(ctx => true, 6, bigIceBlockId, extraBigIceBlockId);
            AddAvoidObject(ctx => true, 3, iceBlockId, iseStoneMountId);
            return new PrioritySelector();
        }

        [ObjectHandler(187882, "Ice Stone", 100)]
        public Composite IceStoneBehavior()
        {
            WoWGameObject stone = null;
            return new PrioritySelector(ctx => stone = ctx as WoWGameObject,
                new Decorator(ctx => Me.IsTank() && Targeting.Instance.IsEmpty() && stone.CanUse(),
                    new PrioritySelector(
                        new Decorator(ctx => !stone.CanUseNow(), new Action(ctx => Navigator.MoveTo(stone.Location))),
                        new Decorator(ctx => !GossipFrame.Instance.IsVisible,
                            new Sequence(
                                new DecoratorContinue(ctx => Me.IsMoving, new Action(ctx => WoWMovement.MoveStop())),
                                new WaitContinue(2, ctx => !Me.IsMoving, new ActionAlwaysSucceed()),
                                new Action(ctx => stone.Interact()))),
                        new Decorator(ctx => GossipFrame.Instance.IsVisible,
                            new Action(ctx => GossipFrame.Instance.SelectGossipOption(0)))
                        ))
                );
        }

    }
}
