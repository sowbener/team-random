﻿namespace ItemForAuraQuesthelper
{
    partial class Config
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB1 = new System.Windows.Forms.CheckBox();
            this.CB2 = new System.Windows.Forms.CheckBox();
            this.CB3 = new System.Windows.Forms.CheckBox();
            this.CB4 = new System.Windows.Forms.CheckBox();
            this.CB5 = new System.Windows.Forms.CheckBox();
            this.CB6 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TBItem1 = new System.Windows.Forms.TextBox();
            this.TBAura1 = new System.Windows.Forms.TextBox();
            this.TBQuest11 = new System.Windows.Forms.TextBox();
            this.TBQuest12 = new System.Windows.Forms.TextBox();
            this.TBQuest13 = new System.Windows.Forms.TextBox();
            this.TBItem2 = new System.Windows.Forms.TextBox();
            this.TBAura2 = new System.Windows.Forms.TextBox();
            this.TBQuest21 = new System.Windows.Forms.TextBox();
            this.TBQuest22 = new System.Windows.Forms.TextBox();
            this.TBQuest23 = new System.Windows.Forms.TextBox();
            this.TBItem3 = new System.Windows.Forms.TextBox();
            this.TBAura3 = new System.Windows.Forms.TextBox();
            this.TBQuest31 = new System.Windows.Forms.TextBox();
            this.TBQuest32 = new System.Windows.Forms.TextBox();
            this.TBQuest33 = new System.Windows.Forms.TextBox();
            this.TBItem4 = new System.Windows.Forms.TextBox();
            this.TBAura4 = new System.Windows.Forms.TextBox();
            this.TBQuest41 = new System.Windows.Forms.TextBox();
            this.TBQuest42 = new System.Windows.Forms.TextBox();
            this.TBQuest43 = new System.Windows.Forms.TextBox();
            this.TBItem5 = new System.Windows.Forms.TextBox();
            this.TBAura5 = new System.Windows.Forms.TextBox();
            this.TBQuest51 = new System.Windows.Forms.TextBox();
            this.TBQuest52 = new System.Windows.Forms.TextBox();
            this.TBQuest53 = new System.Windows.Forms.TextBox();
            this.TBItem6 = new System.Windows.Forms.TextBox();
            this.TBAura6 = new System.Windows.Forms.TextBox();
            this.TBQuest61 = new System.Windows.Forms.TextBox();
            this.TBQuest62 = new System.Windows.Forms.TextBox();
            this.TBQuest63 = new System.Windows.Forms.TextBox();
            this.CBCombat1 = new System.Windows.Forms.CheckBox();
            this.CBCombat2 = new System.Windows.Forms.CheckBox();
            this.CBCombat3 = new System.Windows.Forms.CheckBox();
            this.CBCombat4 = new System.Windows.Forms.CheckBox();
            this.CBCombat5 = new System.Windows.Forms.CheckBox();
            this.CBCombat6 = new System.Windows.Forms.CheckBox();
            this.BSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CB1
            // 
            this.CB1.AutoSize = true;
            this.CB1.Location = new System.Drawing.Point(12, 29);
            this.CB1.Name = "CB1";
            this.CB1.Size = new System.Drawing.Size(15, 14);
            this.CB1.TabIndex = 0;
            this.CB1.UseVisualStyleBackColor = true;
            // 
            // CB2
            // 
            this.CB2.AutoSize = true;
            this.CB2.Location = new System.Drawing.Point(12, 53);
            this.CB2.Name = "CB2";
            this.CB2.Size = new System.Drawing.Size(15, 14);
            this.CB2.TabIndex = 1;
            this.CB2.UseVisualStyleBackColor = true;
            this.CB2.CheckedChanged += new System.EventHandler(this.CB2_CheckedChanged);
            // 
            // CB3
            // 
            this.CB3.AutoSize = true;
            this.CB3.Location = new System.Drawing.Point(12, 77);
            this.CB3.Name = "CB3";
            this.CB3.Size = new System.Drawing.Size(15, 14);
            this.CB3.TabIndex = 2;
            this.CB3.UseVisualStyleBackColor = true;
            this.CB3.CheckedChanged += new System.EventHandler(this.CB3_CheckedChanged);
            // 
            // CB4
            // 
            this.CB4.AutoSize = true;
            this.CB4.Location = new System.Drawing.Point(12, 101);
            this.CB4.Name = "CB4";
            this.CB4.Size = new System.Drawing.Size(15, 14);
            this.CB4.TabIndex = 3;
            this.CB4.UseVisualStyleBackColor = true;
            this.CB4.CheckedChanged += new System.EventHandler(this.CB4_CheckedChanged);
            // 
            // CB5
            // 
            this.CB5.AutoSize = true;
            this.CB5.Location = new System.Drawing.Point(12, 125);
            this.CB5.Name = "CB5";
            this.CB5.Size = new System.Drawing.Size(15, 14);
            this.CB5.TabIndex = 4;
            this.CB5.UseVisualStyleBackColor = true;
            this.CB5.CheckedChanged += new System.EventHandler(this.CB5_CheckedChanged);
            // 
            // CB6
            // 
            this.CB6.AutoSize = true;
            this.CB6.Location = new System.Drawing.Point(12, 149);
            this.CB6.Name = "CB6";
            this.CB6.Size = new System.Drawing.Size(15, 14);
            this.CB6.TabIndex = 5;
            this.CB6.UseVisualStyleBackColor = true;
            this.CB6.CheckedChanged += new System.EventHandler(this.CB6_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Item";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(123, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Aura";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(257, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Quest2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(185, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Quest1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(329, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Quest3";
            // 
            // TBItem1
            // 
            this.TBItem1.Location = new System.Drawing.Point(33, 25);
            this.TBItem1.Name = "TBItem1";
            this.TBItem1.Size = new System.Drawing.Size(66, 20);
            this.TBItem1.TabIndex = 7;
            // 
            // TBAura1
            // 
            this.TBAura1.Location = new System.Drawing.Point(105, 25);
            this.TBAura1.Name = "TBAura1";
            this.TBAura1.Size = new System.Drawing.Size(66, 20);
            this.TBAura1.TabIndex = 7;
            // 
            // TBQuest11
            // 
            this.TBQuest11.Location = new System.Drawing.Point(177, 25);
            this.TBQuest11.Name = "TBQuest11";
            this.TBQuest11.Size = new System.Drawing.Size(66, 20);
            this.TBQuest11.TabIndex = 7;
            // 
            // TBQuest12
            // 
            this.TBQuest12.Location = new System.Drawing.Point(249, 25);
            this.TBQuest12.Name = "TBQuest12";
            this.TBQuest12.Size = new System.Drawing.Size(66, 20);
            this.TBQuest12.TabIndex = 7;
            // 
            // TBQuest13
            // 
            this.TBQuest13.Location = new System.Drawing.Point(321, 25);
            this.TBQuest13.Name = "TBQuest13";
            this.TBQuest13.Size = new System.Drawing.Size(66, 20);
            this.TBQuest13.TabIndex = 7;
            // 
            // TBItem2
            // 
            this.TBItem2.Enabled = false;
            this.TBItem2.Location = new System.Drawing.Point(33, 50);
            this.TBItem2.Name = "TBItem2";
            this.TBItem2.Size = new System.Drawing.Size(66, 20);
            this.TBItem2.TabIndex = 7;
            // 
            // TBAura2
            // 
            this.TBAura2.Enabled = false;
            this.TBAura2.Location = new System.Drawing.Point(105, 50);
            this.TBAura2.Name = "TBAura2";
            this.TBAura2.Size = new System.Drawing.Size(66, 20);
            this.TBAura2.TabIndex = 7;
            // 
            // TBQuest21
            // 
            this.TBQuest21.Enabled = false;
            this.TBQuest21.Location = new System.Drawing.Point(177, 50);
            this.TBQuest21.Name = "TBQuest21";
            this.TBQuest21.Size = new System.Drawing.Size(66, 20);
            this.TBQuest21.TabIndex = 7;
            // 
            // TBQuest22
            // 
            this.TBQuest22.Enabled = false;
            this.TBQuest22.Location = new System.Drawing.Point(249, 50);
            this.TBQuest22.Name = "TBQuest22";
            this.TBQuest22.Size = new System.Drawing.Size(66, 20);
            this.TBQuest22.TabIndex = 7;
            // 
            // TBQuest23
            // 
            this.TBQuest23.Enabled = false;
            this.TBQuest23.Location = new System.Drawing.Point(321, 50);
            this.TBQuest23.Name = "TBQuest23";
            this.TBQuest23.Size = new System.Drawing.Size(66, 20);
            this.TBQuest23.TabIndex = 7;
            // 
            // TBItem3
            // 
            this.TBItem3.Enabled = false;
            this.TBItem3.Location = new System.Drawing.Point(33, 74);
            this.TBItem3.Name = "TBItem3";
            this.TBItem3.Size = new System.Drawing.Size(66, 20);
            this.TBItem3.TabIndex = 7;
            // 
            // TBAura3
            // 
            this.TBAura3.Enabled = false;
            this.TBAura3.Location = new System.Drawing.Point(105, 74);
            this.TBAura3.Name = "TBAura3";
            this.TBAura3.Size = new System.Drawing.Size(66, 20);
            this.TBAura3.TabIndex = 7;
            // 
            // TBQuest31
            // 
            this.TBQuest31.Enabled = false;
            this.TBQuest31.Location = new System.Drawing.Point(177, 74);
            this.TBQuest31.Name = "TBQuest31";
            this.TBQuest31.Size = new System.Drawing.Size(66, 20);
            this.TBQuest31.TabIndex = 7;
            // 
            // TBQuest32
            // 
            this.TBQuest32.Enabled = false;
            this.TBQuest32.Location = new System.Drawing.Point(249, 74);
            this.TBQuest32.Name = "TBQuest32";
            this.TBQuest32.Size = new System.Drawing.Size(66, 20);
            this.TBQuest32.TabIndex = 7;
            // 
            // TBQuest33
            // 
            this.TBQuest33.Enabled = false;
            this.TBQuest33.Location = new System.Drawing.Point(321, 74);
            this.TBQuest33.Name = "TBQuest33";
            this.TBQuest33.Size = new System.Drawing.Size(66, 20);
            this.TBQuest33.TabIndex = 7;
            // 
            // TBItem4
            // 
            this.TBItem4.Enabled = false;
            this.TBItem4.Location = new System.Drawing.Point(33, 98);
            this.TBItem4.Name = "TBItem4";
            this.TBItem4.Size = new System.Drawing.Size(66, 20);
            this.TBItem4.TabIndex = 7;
            // 
            // TBAura4
            // 
            this.TBAura4.Enabled = false;
            this.TBAura4.Location = new System.Drawing.Point(105, 98);
            this.TBAura4.Name = "TBAura4";
            this.TBAura4.Size = new System.Drawing.Size(66, 20);
            this.TBAura4.TabIndex = 7;
            // 
            // TBQuest41
            // 
            this.TBQuest41.Enabled = false;
            this.TBQuest41.Location = new System.Drawing.Point(177, 98);
            this.TBQuest41.Name = "TBQuest41";
            this.TBQuest41.Size = new System.Drawing.Size(66, 20);
            this.TBQuest41.TabIndex = 7;
            // 
            // TBQuest42
            // 
            this.TBQuest42.Enabled = false;
            this.TBQuest42.Location = new System.Drawing.Point(249, 98);
            this.TBQuest42.Name = "TBQuest42";
            this.TBQuest42.Size = new System.Drawing.Size(66, 20);
            this.TBQuest42.TabIndex = 7;
            // 
            // TBQuest43
            // 
            this.TBQuest43.Enabled = false;
            this.TBQuest43.Location = new System.Drawing.Point(321, 98);
            this.TBQuest43.Name = "TBQuest43";
            this.TBQuest43.Size = new System.Drawing.Size(66, 20);
            this.TBQuest43.TabIndex = 7;
            // 
            // TBItem5
            // 
            this.TBItem5.Enabled = false;
            this.TBItem5.Location = new System.Drawing.Point(33, 122);
            this.TBItem5.Name = "TBItem5";
            this.TBItem5.Size = new System.Drawing.Size(66, 20);
            this.TBItem5.TabIndex = 7;
            // 
            // TBAura5
            // 
            this.TBAura5.Enabled = false;
            this.TBAura5.Location = new System.Drawing.Point(105, 122);
            this.TBAura5.Name = "TBAura5";
            this.TBAura5.Size = new System.Drawing.Size(66, 20);
            this.TBAura5.TabIndex = 7;
            // 
            // TBQuest51
            // 
            this.TBQuest51.Enabled = false;
            this.TBQuest51.Location = new System.Drawing.Point(177, 122);
            this.TBQuest51.Name = "TBQuest51";
            this.TBQuest51.Size = new System.Drawing.Size(66, 20);
            this.TBQuest51.TabIndex = 7;
            // 
            // TBQuest52
            // 
            this.TBQuest52.Enabled = false;
            this.TBQuest52.Location = new System.Drawing.Point(249, 122);
            this.TBQuest52.Name = "TBQuest52";
            this.TBQuest52.Size = new System.Drawing.Size(66, 20);
            this.TBQuest52.TabIndex = 7;
            // 
            // TBQuest53
            // 
            this.TBQuest53.Enabled = false;
            this.TBQuest53.Location = new System.Drawing.Point(321, 122);
            this.TBQuest53.Name = "TBQuest53";
            this.TBQuest53.Size = new System.Drawing.Size(66, 20);
            this.TBQuest53.TabIndex = 7;
            // 
            // TBItem6
            // 
            this.TBItem6.Enabled = false;
            this.TBItem6.Location = new System.Drawing.Point(33, 146);
            this.TBItem6.Name = "TBItem6";
            this.TBItem6.Size = new System.Drawing.Size(66, 20);
            this.TBItem6.TabIndex = 7;
            // 
            // TBAura6
            // 
            this.TBAura6.Enabled = false;
            this.TBAura6.Location = new System.Drawing.Point(105, 146);
            this.TBAura6.Name = "TBAura6";
            this.TBAura6.Size = new System.Drawing.Size(66, 20);
            this.TBAura6.TabIndex = 7;
            // 
            // TBQuest61
            // 
            this.TBQuest61.Enabled = false;
            this.TBQuest61.Location = new System.Drawing.Point(177, 146);
            this.TBQuest61.Name = "TBQuest61";
            this.TBQuest61.Size = new System.Drawing.Size(66, 20);
            this.TBQuest61.TabIndex = 7;
            // 
            // TBQuest62
            // 
            this.TBQuest62.Enabled = false;
            this.TBQuest62.Location = new System.Drawing.Point(249, 146);
            this.TBQuest62.Name = "TBQuest62";
            this.TBQuest62.Size = new System.Drawing.Size(66, 20);
            this.TBQuest62.TabIndex = 7;
            // 
            // TBQuest63
            // 
            this.TBQuest63.Enabled = false;
            this.TBQuest63.Location = new System.Drawing.Point(321, 146);
            this.TBQuest63.Name = "TBQuest63";
            this.TBQuest63.Size = new System.Drawing.Size(66, 20);
            this.TBQuest63.TabIndex = 7;
            // 
            // CBCombat1
            // 
            this.CBCombat1.AutoSize = true;
            this.CBCombat1.Location = new System.Drawing.Point(393, 27);
            this.CBCombat1.Name = "CBCombat1";
            this.CBCombat1.Size = new System.Drawing.Size(75, 17);
            this.CBCombat1.TabIndex = 8;
            this.CBCombat1.Text = "use Infight";
            this.CBCombat1.UseVisualStyleBackColor = true;
            // 
            // CBCombat2
            // 
            this.CBCombat2.AutoSize = true;
            this.CBCombat2.Enabled = false;
            this.CBCombat2.Location = new System.Drawing.Point(393, 52);
            this.CBCombat2.Name = "CBCombat2";
            this.CBCombat2.Size = new System.Drawing.Size(75, 17);
            this.CBCombat2.TabIndex = 8;
            this.CBCombat2.Text = "use Infight";
            this.CBCombat2.UseVisualStyleBackColor = true;
            // 
            // CBCombat3
            // 
            this.CBCombat3.AutoSize = true;
            this.CBCombat3.Enabled = false;
            this.CBCombat3.Location = new System.Drawing.Point(393, 76);
            this.CBCombat3.Name = "CBCombat3";
            this.CBCombat3.Size = new System.Drawing.Size(75, 17);
            this.CBCombat3.TabIndex = 8;
            this.CBCombat3.Text = "use Infight";
            this.CBCombat3.UseVisualStyleBackColor = true;
            // 
            // CBCombat4
            // 
            this.CBCombat4.AutoSize = true;
            this.CBCombat4.Enabled = false;
            this.CBCombat4.Location = new System.Drawing.Point(393, 100);
            this.CBCombat4.Name = "CBCombat4";
            this.CBCombat4.Size = new System.Drawing.Size(75, 17);
            this.CBCombat4.TabIndex = 8;
            this.CBCombat4.Text = "use Infight";
            this.CBCombat4.UseVisualStyleBackColor = true;
            // 
            // CBCombat5
            // 
            this.CBCombat5.AutoSize = true;
            this.CBCombat5.Enabled = false;
            this.CBCombat5.Location = new System.Drawing.Point(393, 124);
            this.CBCombat5.Name = "CBCombat5";
            this.CBCombat5.Size = new System.Drawing.Size(75, 17);
            this.CBCombat5.TabIndex = 8;
            this.CBCombat5.Text = "use Infight";
            this.CBCombat5.UseVisualStyleBackColor = true;
            // 
            // CBCombat6
            // 
            this.CBCombat6.AutoSize = true;
            this.CBCombat6.Enabled = false;
            this.CBCombat6.Location = new System.Drawing.Point(393, 148);
            this.CBCombat6.Name = "CBCombat6";
            this.CBCombat6.Size = new System.Drawing.Size(75, 17);
            this.CBCombat6.TabIndex = 8;
            this.CBCombat6.Text = "use Infight";
            this.CBCombat6.UseVisualStyleBackColor = true;
            // 
            // BSave
            // 
            this.BSave.Location = new System.Drawing.Point(197, 181);
            this.BSave.Name = "BSave";
            this.BSave.Size = new System.Drawing.Size(75, 23);
            this.BSave.TabIndex = 9;
            this.BSave.Text = "Save";
            this.BSave.UseVisualStyleBackColor = true;
            this.BSave.Click += new System.EventHandler(this.BSave_Click);
            // 
            // Config
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 216);
            this.Controls.Add(this.BSave);
            this.Controls.Add(this.CBCombat6);
            this.Controls.Add(this.CBCombat5);
            this.Controls.Add(this.CBCombat4);
            this.Controls.Add(this.CBCombat3);
            this.Controls.Add(this.CBCombat2);
            this.Controls.Add(this.CBCombat1);
            this.Controls.Add(this.TBQuest63);
            this.Controls.Add(this.TBQuest53);
            this.Controls.Add(this.TBQuest43);
            this.Controls.Add(this.TBQuest33);
            this.Controls.Add(this.TBQuest23);
            this.Controls.Add(this.TBQuest13);
            this.Controls.Add(this.TBQuest62);
            this.Controls.Add(this.TBQuest61);
            this.Controls.Add(this.TBQuest52);
            this.Controls.Add(this.TBQuest51);
            this.Controls.Add(this.TBQuest42);
            this.Controls.Add(this.TBQuest41);
            this.Controls.Add(this.TBQuest32);
            this.Controls.Add(this.TBAura6);
            this.Controls.Add(this.TBQuest31);
            this.Controls.Add(this.TBAura5);
            this.Controls.Add(this.TBQuest22);
            this.Controls.Add(this.TBAura4);
            this.Controls.Add(this.TBQuest21);
            this.Controls.Add(this.TBItem6);
            this.Controls.Add(this.TBAura3);
            this.Controls.Add(this.TBItem5);
            this.Controls.Add(this.TBQuest12);
            this.Controls.Add(this.TBItem4);
            this.Controls.Add(this.TBAura2);
            this.Controls.Add(this.TBItem3);
            this.Controls.Add(this.TBQuest11);
            this.Controls.Add(this.TBItem2);
            this.Controls.Add(this.TBAura1);
            this.Controls.Add(this.TBItem1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CB6);
            this.Controls.Add(this.CB5);
            this.Controls.Add(this.CB4);
            this.Controls.Add(this.CB3);
            this.Controls.Add(this.CB2);
            this.Controls.Add(this.CB1);
            this.Name = "Config";
            this.Text = "Config Window";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox CB1;
        private System.Windows.Forms.CheckBox CB2;
        private System.Windows.Forms.CheckBox CB3;
        private System.Windows.Forms.CheckBox CB4;
        private System.Windows.Forms.CheckBox CB5;
        private System.Windows.Forms.CheckBox CB6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TBItem1;
        private System.Windows.Forms.TextBox TBAura1;
        private System.Windows.Forms.TextBox TBQuest11;
        private System.Windows.Forms.TextBox TBQuest12;
        private System.Windows.Forms.TextBox TBQuest13;
        private System.Windows.Forms.TextBox TBItem2;
        private System.Windows.Forms.TextBox TBAura2;
        private System.Windows.Forms.TextBox TBQuest21;
        private System.Windows.Forms.TextBox TBQuest22;
        private System.Windows.Forms.TextBox TBQuest23;
        private System.Windows.Forms.TextBox TBItem3;
        private System.Windows.Forms.TextBox TBAura3;
        private System.Windows.Forms.TextBox TBQuest31;
        private System.Windows.Forms.TextBox TBQuest32;
        private System.Windows.Forms.TextBox TBQuest33;
        private System.Windows.Forms.TextBox TBItem4;
        private System.Windows.Forms.TextBox TBAura4;
        private System.Windows.Forms.TextBox TBQuest41;
        private System.Windows.Forms.TextBox TBQuest42;
        private System.Windows.Forms.TextBox TBQuest43;
        private System.Windows.Forms.TextBox TBItem5;
        private System.Windows.Forms.TextBox TBAura5;
        private System.Windows.Forms.TextBox TBQuest51;
        private System.Windows.Forms.TextBox TBQuest52;
        private System.Windows.Forms.TextBox TBQuest53;
        private System.Windows.Forms.TextBox TBItem6;
        private System.Windows.Forms.TextBox TBAura6;
        private System.Windows.Forms.TextBox TBQuest61;
        private System.Windows.Forms.TextBox TBQuest62;
        private System.Windows.Forms.TextBox TBQuest63;
        private System.Windows.Forms.CheckBox CBCombat1;
        private System.Windows.Forms.CheckBox CBCombat2;
        private System.Windows.Forms.CheckBox CBCombat3;
        private System.Windows.Forms.CheckBox CBCombat4;
        private System.Windows.Forms.CheckBox CBCombat5;
        private System.Windows.Forms.CheckBox CBCombat6;
        private System.Windows.Forms.Button BSave;
    }
}

