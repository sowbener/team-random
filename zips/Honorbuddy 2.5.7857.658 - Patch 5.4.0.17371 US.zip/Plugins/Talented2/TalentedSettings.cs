﻿using System;
using System.IO;
using System.Reflection;
using System.Xml.Linq;
using Styx;
using Styx.Helpers;
using Styx.Common;

namespace Talented
{
    class TalentedSettings : Settings
    {
        public static TalentedSettings Instance = new TalentedSettings();

        public TalentedSettings() 
            : base(Path.Combine(Utilities.AssemblyDirectory, string.Format("Settings\\{0}\\{1}\\Talented2Settings.xml", StyxWoW.Me.RealmName, StyxWoW.Me.Name)),
                   Path.Combine(Utilities.AssemblyDirectory, string.Format("Settings\\Talented2Settings_{0}.xml", StyxWoW.Me.Name)))
        {
        }

        public static readonly string PluginFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), Path.Combine("Plugins", "Talented2"));

        [Setting(Explanation = "The name of the last used Talent Build."), DefaultValue("")]
        public string ChoosenTalentBuildName { get; set; }

        [Setting(Explanation = "The class of the last used Talent Build."), DefaultValue(WoWClass.None)]
        public WoWClass ChoosenTalentClass { get; set; }
        
        public TalentTree ChoosenTalentBuild
        {
            get
            {
                if (string.IsNullOrEmpty(ChoosenTalentBuildName) || ChoosenTalentClass == WoWClass.None)
                    return null;

                var dataDirectory = Path.Combine(Utilities.AssemblyDirectory, "Data");
                var talentBuildPath = Path.Combine(dataDirectory, "Talent Builds");
                string[] files = Directory.GetFiles(talentBuildPath, "*.xml", SearchOption.AllDirectories);
                for (int i = 0; i < files.Length; i++)
                {
                    string file = files[i];

                    TalentTree talentTree = TalentTree.FromXml(XElement.Load(file));
                    if (talentTree != null && talentTree.BuildName == ChoosenTalentBuildName && talentTree.Class == ChoosenTalentClass)
                        return talentTree;

                }

                return null;
            }
        }
    }
}
