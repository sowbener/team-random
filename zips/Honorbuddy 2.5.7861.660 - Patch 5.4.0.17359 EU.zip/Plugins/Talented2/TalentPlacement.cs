﻿namespace Talented
{
    public class TalentPlacement
    {
        public int Tier;
        public int Index;
        public string Name;

        public TalentPlacement(int tier, int index)
        {
            Tier = tier;
            Index = index;
        }

        public TalentPlacement(int tier, int index, string name)
        {
            Tier = tier;
            Index = index;
            Name = name;
        }

        public override string ToString()
        {
            return string.Format("{0}", Name);
        }
    }
}
