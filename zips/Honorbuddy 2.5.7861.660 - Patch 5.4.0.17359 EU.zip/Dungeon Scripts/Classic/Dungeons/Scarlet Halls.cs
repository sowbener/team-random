﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonBuddyScripts.Dungeon_Scripts.Classic.Dungeons
{
    class Scarlet_Halls
    {
    }
}
